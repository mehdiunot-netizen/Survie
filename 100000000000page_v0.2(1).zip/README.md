# 100000000000page — version jouable v0.1
Test sur iPhone : publier ce dossier tel quel (GitHub Pages : Settings → Pages → branche main, dossier /root), puis ouvrir le lien dans Safari. Connexion requise (Three.js chargé depuis jsDelivr). L'aperçu « Fichiers » d'iOS ne convient pas.
Tests logiques : `node tests/test.js`.
Commandes : joystick à gauche, glisser ailleurs pour regarder, bouton d'action contextuel (ramasser / vendre / ordinateur), SAUTER.

## Réalisé (logique testée sous Node ; rendu 3D NON testé dans un navigateur)
- Couloir, 5 000 000 feuilles en 10 tas escaladables, ramassage 3-4, inventaire 4×100, broyeur proportionnel
- Magasin (100 feuilles), armurerie (balle → broyeur), casino (100 crédits), 3 robots, améliorations, réparations
- Armurerie : lampe, pistolet, Kalachnikov, fusil à pompe, dynamite (achat à l'ordinateur) ; bouton TIRER pour abattre une créature avant qu'elle frappe un robot
- Casino jouable : roulette américaine (38 cases) et machine à sous, mises 10/25/50 (porte du casino, mur gauche)
- 4 arbres de compétences (collecte, robotique, logistique, survie), niv. 5 max, 1 point / 1000 feuilles vendues
- Variantes secrètes par code à l'ordinateur : horreur (créature mortelle pour le joueur), doree, neon
- Créatures : version normale = uniquement les robots ; sauvegarde locale

## À développer
Vraies armes visuelles / munitions / lampe torche (effet), salle de casino 3D, animation réelle des robots, catastrophes, quotas, seaux, plus de variantes, retrait du HUD provisoire au profit d'ordinateurs physiques, équilibrage, test et optimisation sur iPhone réel.

## Approximations (changelog)
Prix par feuille 0,5 cr, 0,04 s/feuille au broyeur : « à équilibrer ». Amélioration = +1 PV immédiat aux robots actifs. Robots animés par simple va-et-vient.
Anciens prototypes conservés : prototypes/.
Armes : une arme possédée suffit à tirer (pas de munitions ni de différences de dégâts). Variantes : codes horreur, doree, neon.
