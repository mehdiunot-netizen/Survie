const G=require('../js/logic.js');const assert=require('assert');
let s=G.newState();assert.strictEqual(s.piles.reduce((a,b)=>a+b,0),5000000);
// ramassage 3-4 & stock exact
let n=0;for(let i=0;i<40;i++){const k=G.pick(s,0);assert(k===3||k===4);n+=k}
assert.strictEqual(s.collected,n);assert.strictEqual(s.piles.reduce((a,b)=>a+b,0),5000000-n);assert(s.unlocked.shop,'magasin après 100');
// inventaire plein : 4x100
s=G.newState();while(G.pick(s,0));assert.strictEqual(G.carried(s),400);
// broyeur : durée proportionnelle, crédits à la fin
let t0=1000;assert(G.startCrush(s,t0));assert(s.crush.dur>=2000);assert.strictEqual(G.tickCrush(s,t0+100),null);
let r=G.tickCrush(s,t0+s.crush.dur);assert.strictEqual(r.gain,200);assert.strictEqual(s.credits,200);assert.strictEqual(s.sold,400);
// balle -> armurerie
s.bullet=1;G.startCrush(s,0);assert(!s.unlocked.armory);assert(G.tickCrush(s,1e6).armory);assert(s.unlocked.armory);
// robots
s=G.newState();s.unlocked.shop=true;assert(!G.buyRobot(s,'normal'));s.credits=1000;assert(G.buyRobot(s,'normal'));assert.strictEqual(s.credits,850);
G.tickRobots(s,60);assert.strictEqual(s.cubes.reduce((a,c)=>a+c.n,0)+s.robots[0].carry,100);
G.hit(s,0);G.hit(s,0);assert.strictEqual(s.robots[0].hp,0);const before=s.credits;assert(G.repair(s,0));assert.strictEqual(before-s.credits,30);assert.strictEqual(s.robots[0].hp,2);
assert(G.buyUpgrade(s,'normal'));assert.strictEqual(s.upgrades.normal,1);
// casino : accès unique 100
s.credits=150;assert(G.buyCasino(s));assert.strictEqual(s.credits,50);assert(!G.buyCasino(s));
// RTP machine à sous (exact) et roulette rouge
let tot=0;for(let a=0;a<6;a++)for(let b=0;b<6;b++)for(let c=0;c<6;c++)tot+=G.slotPayout(a,b,c);
assert(Math.abs(tot/216-0.9306)<0.001,'RTP slots '+tot/216);
let red=0;for(let i=0;i<38;i++)red+=G.roulettePayout({type:'rouge'},i);assert(Math.abs(red/38-0.9474)<0.001);
let num=0;for(let i=0;i<38;i++)num+=G.roulettePayout({type:'numero',val:7},i);assert(Math.abs(num/38-36/38)<1e-9);
// sauvegarde
const mem={d:{},setItem(k,v){this.d[k]=v},getItem(k){return this.d[k]}};G.save(s,mem);assert.deepStrictEqual(G.load(mem),s);
// compétences, armes, variantes
s=G.newState();s.sold=3000;assert.strictEqual(G.skillPts(s),3);G.buySkill(s,'col');G.buySkill(s,'col');assert.strictEqual(G.skillPts(s),1);assert(!G.buySkill(s,'xx'));
s.skills.col=2;assert(G.pick(s,0)>=4);
assert(!G.buyWeapon(s,'pistolet'));s.unlocked.armory=true;s.credits=1000;assert(G.buyWeapon(s,'pistolet'));assert(!G.buyWeapon(s,'pistolet'));assert(G.shoot(s));
s=G.newState();s.unlocked.armory=true;s.credits=300;G.buyWeapon(s,'dynamite');assert(G.shoot(s));assert(!G.shoot(s));
assert(G.setVariant(s,' Horreur ')&&s.variant==='horreur'&&!G.setVariant(s,'zzz'));
console.log('Tous les tests logiques passent ✔');
