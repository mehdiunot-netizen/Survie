# 100000000000page — Cahier des charges consolidé

Version : 23 novembre 2026. Cette fiche rassemble les décisions de notre conversation. Les dernières précisions prévalent sur les idées abandonnées. Les montants non fixés ne sont pas inventés.

## Vision du jeu et plateforme
- Jeu de collecte/gestion 3D, ambiance industrielle sérieuse, pouvant devenir horrifique dans des variantes secrètes.
- Destiné d'abord au navigateur **Safari sur iPhone**, utilisable par lien web (pas d'App Store requis), avec commandes tactiles. Technologie web légère, compatible avec un hébergement statique tel que GitHub Pages.
- **Un seul et immense espace industriel** : entrepôt sous la forme d'un couloir gigantesque, continu, très haut et très long. Pas de monde ouvert à explorer, pas de succession de salles ou de rangées d'étagères à parcourir. Quelques machines, obstacles et éléments industriels; un mur invisible limite l'aire jouable.
- **Extensions** accessibles par des portes sur les côtés : magasin, armurerie, casino (salle de gambling). Chaque porte affiche physiquement sa condition d'ouverture. Les quêtes débloquent les portes définitivement. Les événements peuvent perturber momentanément des activités et machines.
- Aucun HUD classique dans la version finale : heure, argent, quotas, compétences et statistiques sont consultables sur un **ordinateur dans le monde**. Terminal portable à débloquer plus tard. Le prototype existant peut encore afficher une interface provisoire.

## But et feuilles
- Un objectif de l'ordre de **5 millions de feuilles** a été évoqué, avec quotas journaliers et objectif global variables selon les événements. Ce n'est pas une quantité fixe définitive pour toutes les parties.
- **Des millions de feuilles existent réellement dans le monde dès le départ**; pas de génération infinie qui imiterait cette réserve. Pour tenir sur téléphone, les représenter par des agrégats 3D et un comptage exact en données : ne pas fabriquer des millions d'objets 3D individuels.
- Les feuilles sont **uniquement par terre**, sous forme de **très grosses montagnes de papier** dans le même entrepôt/couloir. Le joueur peut **monter facilement sur les tas**, sans mécanique de glissade ou risque de chute imposé pour cette action. Les montagnes rétrécissent visuellement lorsque le stock diminue.
- Chaque ramassage manuel récupère un petit lot de **3 ou 4 feuilles** ; le total réel baisse d'autant. Ne pas confondre une poignée ramassée avec la taille totale des tas.
- Inventaire du joueur : **4 emplacements de 100 feuilles chacun**. Le **seau** est un outil qui sert à prendre les feuilles et les cubes des robots; ses capacités propres restent à définir.
- Un compteur interne doit suivre précisément le nombre de feuilles total, collecté, vendu et restant. Sauvegarder la progression localement.

## Broyeur et économie
- Les feuilles ramassées et les **cubes de collecte** sont apportés au **broyeur** pour être vendus. Le joueur doit intervenir lui-même pour vendre; les robots ne vendent pas automatiquement.
- Temps de broyage **proportionnel à la quantité apportée**, sur plusieurs secondes. Les **crédits ne sont attribués qu'à la fin** du broyage. Le broyeur doit afficher dans le monde les quantités traitées et le résultat.
- Les robots vont physiquement au point de vente et y déposent **chacun leur cube**. Les variantes de robots ont des cubes visuellement distincts. Le cube représente une quantité de feuilles réelle. Le joueur peut récupérer plusieurs cubes avec un seau et les mettre au broyeur.
- Prix de vente par feuille, temps de broyage exact, capacités du seau : **non fixés**. Les concevoir comme des paramètres configurables, clairement marqués « à équilibrer ».

## Première quête, portes et balle
- **Magasin** : collecter **100 feuilles au total** pour ouvrir définitivement sa porte; la progression compte même les feuilles déjà vendues, et la validation n'enlève pas les feuilles à l'inventaire.
- **Armurerie** : **trouver une balle de munition située tout en haut d'une énorme montagne de feuilles**, la ramasser, puis la déposer dans le **broyeur**. Une fois broyée, la porte s'ouvre définitivement. La balle reste récupérable même si le tas est entamé par les robots.
- **Important : la condition « subir un coma » pour ouvrir l'armurerie a été remplacée par la balle dans le broyeur.** Ne pas restaurer l'ancienne règle.
- **Casino** : paiement **unique de 100 crédits** pour un accès permanent, pas de ticket d'entrée à chaque visite.

## Seaux et magasin
| Objet | Achat |
| --- | ---: |
| Seau de base | gratuit |
| Seau moyen | 200 crédits |
| Grand seau | 800 crédits |

- Le seau prend les feuilles et les cubes, **pas de l'eau purifiée** (cet élément provenait d'un autre jeu et ne fait pas partie de celui-ci).
- Le magasin fournit robots, améliorations et réparations payantes.

## Robots de collecte
| Modèle | Prix achat | Vitesse nominale | Réparation instantanée |
| --- | ---: | ---: | ---: |
| Ramasseur de feuilles | 150 crédits | 100 feuilles/min | 30 crédits |
| Ramasseur de feuilles Pro | 500 crédits | 500 feuilles/min | 100 crédits |
| Ramasseur de feuilles Max | 1500 crédits | 2000 feuilles/min | 300 crédits |

- Achat possible en plusieurs exemplaires. Les vitesses sont atteignables **si le chemin et les ressources le permettent**; transport, catastrophes et interruptions influent sur le rendement réel.
- Les robots peuvent être endommagés et arrêtés par des créatures; le joueur **paie simplement** pour les réparer et ils reprennent immédiatement le travail. Pas de collecte de pièces, pas de mini-jeu. Les améliorations acquises sont conservées.
- Résistance validée :

| Niveau | Normal | Pro | Max | Coût du niveau |
| --- | ---: | ---: | ---: | ---: |
| Base | 2 coups | 3 coups | 5 coups | 0 |
| 1 | 3 coups | 4 coups | 7 coups | 100 crédits |
| 2 | 4 coups | 5 coups | 9 coups | 300 crédits |
| 3 | 5 coups | 6 coups | 10 coups | 700 crédits |

- Améliorations progressives, **même tarif quel que soit le modèle**. Interpréter les coups comme une limite de résistance et documenter quand exactement le robot s'arrête lors d'un impact.

## Créatures, comas, versions du monde
- **Gameplay normal/de base** : seules existent des créatures **qui attaquent les robots**. Elles **n'attaquent jamais le joueur et ne perturbent pas directement sa récolte manuelle**.
- Trois comportements retenus : 1) frappe un robot frontalement; 2) bondit sur le robot, frappe et s'enfuit; 3) s'accroche au robot et le détériore tant qu'il n'est pas retiré/éliminé.
- Les armes permettent de **tuer** ces créatures afin de protéger les robots.
- Dans les **variantes horrifiques secrètes**, des créatures peuvent attaquer et tuer le joueur. Deux attaques qui devraient le tuer le plongent dans un coma; **la troisième est une mort définitive** et impose une nouvelle partie. Pas de compteur explicite de vies.
- Le monde a plusieurs variantes secrètes : horrifiques, une normale rare où il est possible de gagner, et une maudite ultra-rare avec conclusion catastrophique / screamer. Les indices ne confirment jamais à coup sûr la variante.
- Des catastrophes peuvent interrompre les robots, mais **seules les créatures peuvent tuer le joueur**. Ne pas faire mourir le joueur à cause d'une catastrophe environnementale.

## Armurerie — équipement initial
| Article | Prix |
| --- | ---: |
| Lampe torche | 50 crédits |
| Pistolet | 250 crédits |
| Kalachnikov | 750 crédits |
| Fusil à pompe | 1000 crédits |
| Dynamite | 300 crédits / unité |
| Lot de munitions de pistolet | 50 crédits |
| Lot de munitions de Kalachnikov | 100 crédits |
| Lot de cartouches | 125 crédits |

- Armes conservées après achat; munitions consommables; dynamite utilisable une fois. Prix confirmés; nombre de munitions par lot non encore défini. Ces éléments sont purement des mécaniques fictives de jeu.

## Casino — entièrement fictif, sans transactions réelles
- Prix d'accès **100 crédits une seule fois**; ensuite accès permanent. Aucun achat en argent réel.
- Roulette américaine **38 cases (1–36, 0, 00)**. Paiements totaux : rouge/noir ×2, pair/impair ×2, douzaine ×3, numéro exact (y compris 0 et 00) ×36. La mise est incluse dans le multiplicateur.
- Machine à sous : **3 rouleaux**, symboles 🍒, 🍋, 🔔, ⭐, 7, 💎. Paiement total si trois identiques : ×3, ×4, ×6, ×8, ×15, ×30, respectivement. Exactement deux identiques : ×1,5. Trois différents : ×0. Mises : 10, 25, 50 crédits.
- Règle de conception : chances de gagner et rendement à peu près proches entre jeux, sans gains garantis. **Proposition d'équilibrage** : six symboles uniformément probables et indépendants sur les trois rouleaux donnent 44,44 % de parties payantes, un retour moyen de 93,06 % de la mise; rouge/noir à la roulette gagne avec probabilité 47,37 %, retour moyen 94,74 %. Ce paramétrage n'est pas une obligation confirmée pour la version finale.

## Compétences / progression
- 4 arbres : collecte, robotique, logistique, survie.
- Points limités : impossible de tout débloquer. Réinitialisation possible contre crédits.
- Compétences secrètes acquises automatiquement et gratuitement dès que leurs conditions cachées sont satisfaites.
- La progression de quêtes, le solde, les robots, les améliorations, la variante secrète et les stocks doivent persister en sauvegarde.

## Premières minutes et ambiance
- Démarrage dans le même vaste couloir industriel avec accès initial restreint aux extensions. Le joueur voit physiquement la porte du magasin avec « Ramasser 100 feuilles ».
- Le joueur ramasse au sol par lots de 3–4, observe les grandes montagnes, découvre le broyeur et vend ses feuilles. Les événements sont annoncés par l'environnement (néons, annonces, machines), pas par un tutoriel intrusif ou un HUD.
- La balle à chercher est **sur un tas d'où le joueur peut grimper** : pas de labyrinthe à explorer, pas de zones complexes ou de quête de clés artificielles.

## État réel du code — IMPORTANT
- Les deux fichiers HTML dans cette archive sont **deux prototypes expérimentaux antérieurs**, pas le jeu final. `index.html` affiche un environnement 3D basique et un joystick; l'ancienne version dans `prototypes/` teste notamment de gros tas, broyeur et balle, avec des limitations.
- Le code reste à tester sur iPhone en tant que **vrai site web**. Il dépend de Three.js via CDN et peut échouer dans l'aperçu « Fichiers » d'iOS; cet aperçu n'est pas un navigateur web complet.
- Ne pas prétendre que les millions de feuilles, robots, quêtes, casino, sauvegardes, et variantes sont tous implémentés : ils sont décrits ici, **à développer**.
- Le dépôt déjà créé pour le projet est `Mehdti/100000000000page`, branche `main`. Le propriétaire a eu des problèmes d'autorisations de connexion ChatGPT et d'authentification Codespaces. Éviter de faire dépendre le développement de Codespaces et ne pas demander de longues manipulations mobiles.
